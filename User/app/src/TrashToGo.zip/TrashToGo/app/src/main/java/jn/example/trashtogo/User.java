package jn.example.trashtogo;

public class User {
    public String uid;
    public String type;

    public User(){

    }

    public User(String uid,String type){
        this.uid = uid;
        this.type = type;
    }
}
